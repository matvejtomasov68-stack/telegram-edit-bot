import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class Product:
    id: str
    title: str
    description: str
    price_minor: int


@dataclass(frozen=True, slots=True)
class Category:
    id: str
    title: str
    description: str
    products: tuple[Product, ...]


class Catalog:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.currency = "BYN"
        self.categories: tuple[Category, ...] = ()

    def reload(self) -> None:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise RuntimeError(f"Файл каталога не найден: {self.path}") from exc
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Ошибка JSON в каталоге: {exc}") from exc

        currency = str(raw.get("currency", "BYN")).strip().upper()
        if not currency or len(currency) > 8:
            raise RuntimeError("Некорректная валюта в catalog.json")

        categories: list[Category] = []
        category_ids: set[str] = set()
        product_ids: set[str] = set()

        for category_raw in raw.get("categories", []):
            category_id = self._safe_id(category_raw.get("id"), "категории")
            if category_id in category_ids:
                raise RuntimeError(f"Повторяется ID категории: {category_id}")
            category_ids.add(category_id)

            products: list[Product] = []
            for product_raw in category_raw.get("products", []):
                product_id = self._safe_id(product_raw.get("id"), "товара")
                if product_id in product_ids:
                    raise RuntimeError(f"Повторяется ID товара: {product_id}")
                product_ids.add(product_id)

                price_minor = product_raw.get("price_minor")
                if not isinstance(price_minor, int) or price_minor < 0:
                    raise RuntimeError(
                        f"price_minor товара {product_id} должен быть целым числом >= 0"
                    )
                products.append(
                    Product(
                        id=product_id,
                        title=str(product_raw.get("title", "Без названия")).strip(),
                        description=str(product_raw.get("description", "")).strip(),
                        price_minor=price_minor,
                    )
                )

            categories.append(
                Category(
                    id=category_id,
                    title=str(category_raw.get("title", "Без названия")).strip(),
                    description=str(category_raw.get("description", "")).strip(),
                    products=tuple(products),
                )
            )

        self.currency = currency
        self.categories = tuple(categories)

    @staticmethod
    def _safe_id(value: object, entity: str) -> str:
        item_id = str(value or "").strip()
        if not item_id or len(item_id) > 30:
            raise RuntimeError(f"ID {entity} должен содержать от 1 до 30 символов")
        if not all(
            char.isascii() and (char.isalnum() or char in "_-") for char in item_id
        ):
            raise RuntimeError(
                f"ID {entity} может содержать только латинские буквы, цифры, _ и -"
            )
        return item_id

    def category(self, category_id: str) -> Category | None:
        return next((item for item in self.categories if item.id == category_id), None)

    def product(self, product_id: str) -> Product | None:
        for category in self.categories:
            found = next(
                (item for item in category.products if item.id == product_id), None
            )
            if found:
                return found
        return None

    def category_for_product(self, product_id: str) -> Category | None:
        return next(
            (
                category
                for category in self.categories
                if any(product.id == product_id for product in category.products)
            ),
            None,
        )


def format_money(amount_minor: int, currency: str) -> str:
    if currency.upper() == "G" and amount_minor % 100 == 0:
        return f"{amount_minor // 100}G"
    return f"{amount_minor / 100:.2f} {currency}"
