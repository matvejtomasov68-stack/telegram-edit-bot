import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class Quote:
    seconds: int
    unit_price: int
    base_price: int
    shake_price: int
    discount: int
    total: int
    promo_code: str


class PromoCodeError(ValueError):
    pass


class Pricing:
    def __init__(
        self,
        promocodes_path: Path,
        unit_price: int = 2,
        shake_surcharge: int = 20,
    ) -> None:
        self.promocodes_path = promocodes_path
        self.unit_price = unit_price
        self.shake_surcharge = shake_surcharge

    def quote(self, seconds: int, shake: bool, promo_code: str = "") -> Quote:
        if not 5 <= seconds <= 60:
            raise ValueError("Эдит заказать можно от 5с - 60с")

        base_price = seconds * self.unit_price
        shake_price = self.shake_surcharge if shake else 0
        subtotal = base_price + shake_price
        normalized_code = promo_code.strip().upper()
        discount = self._discount(normalized_code, subtotal) if normalized_code else 0

        return Quote(
            seconds=seconds,
            unit_price=self.unit_price,
            base_price=base_price,
            shake_price=shake_price,
            discount=discount,
            total=max(0, subtotal - discount),
            promo_code=normalized_code,
        )

    def _discount(self, code: str, subtotal: int) -> int:
        try:
            raw = json.loads(self.promocodes_path.read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise PromoCodeError("Промокоды временно недоступны") from exc
        except json.JSONDecodeError as exc:
            raise PromoCodeError("Ошибка настройки промокодов") from exc

        promo = next(
            (
                item
                for item in raw.get("promocodes", [])
                if str(item.get("code", "")).strip().upper() == code
                and bool(item.get("active", True))
            ),
            None,
        )
        if promo is None:
            raise PromoCodeError("Промокод не найден")

        value = promo.get("value")
        if not isinstance(value, int) or value < 0:
            raise PromoCodeError("Промокод настроен неправильно")

        discount_type = promo.get("type", "fixed")
        if discount_type == "fixed":
            return min(subtotal, value)
        if discount_type == "percent" and value <= 100:
            return subtotal * value // 100
        raise PromoCodeError("Промокод настроен неправильно")
