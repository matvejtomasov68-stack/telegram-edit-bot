from aiogram.fsm.state import State, StatesGroup


class Checkout(StatesGroup):
    waiting_phone = State()
    waiting_comment = State()


class ReviewForm(StatesGroup):
    waiting_rating = State()
    waiting_text = State()
