from html import escape
from typing import Any

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from .catalog import Catalog, format_money
from .config import Settings
from .database import Database
from .keyboards import (
    BTN_CANCEL,
    BTN_HISTORY,
    BTN_REVIEWS,
    BTN_SHOP,
    BTN_SKIP,
    cart_keyboard,
    category_keyboard,
    comment_keyboard,
    history_keyboard,
    main_menu,
    phone_keyboard,
    product_keyboard,
    rating_keyboard,
    store_keyboard,
)
from .states import Checkout, ReviewForm

STATUS_LABELS = {
    "pending": "⏳ ожидает подтверждения",
    "completed": "✅ завершён",
    "canceled": "❌ отменён",
}


def create_router(database: Database, catalog: Catalog, settings: Settings) -> Router:
    router = Router(name="shop")

    def reload_catalog() -> None:
        # Изменения в catalog.json подхватываются без перезапуска бота.
        catalog.reload()

    async def ensure_user(message: Message) -> None:
        if message.from_user:
            await database.upsert_user(
                message.from_user.id,
                message.from_user.username,
                message.from_user.first_name,
            )

    async def edit_callback(
        callback: CallbackQuery, text: str, reply_markup: Any = None
    ) -> None:
        if not callback.message:
            return
        try:
            await callback.message.edit_text(text, reply_markup=reply_markup)
        except TelegramBadRequest as exc:
            if "message is not modified" not in str(exc).lower():
                raise

    async def prepared_cart(user_id: int) -> list[dict[str, object]]:
        reload_catalog()
        result: list[dict[str, object]] = []
        for row in await database.cart(user_id):
            product = catalog.product(str(row["product_id"]))
            if product is None:
                # Удалённый из каталога товар не должен мешать оформлению.
                await database.remove_cart_item(user_id, str(row["product_id"]))
                continue
            quantity = int(row["quantity"])
            result.append(
                {
                    "product_id": product.id,
                    "title": product.title,
                    "price_minor": product.price_minor,
                    "quantity": quantity,
                    "subtotal_minor": product.price_minor * quantity,
                }
            )
        return result

    def cart_text(items: list[dict[str, object]]) -> str:
        if not items:
            return "🛒 <b>Корзина пуста</b>\n\nДобавьте товар из магазина."
        lines = ["🛒 <b>Ваша корзина</b>", ""]
        total = 0
        for item in items:
            subtotal = int(item["subtotal_minor"])
            total += subtotal
            lines.append(
                f"• {escape(str(item['title']))} × {item['quantity']} — "
                f"{format_money(subtotal, catalog.currency)}"
            )
        lines.extend(["", f"<b>Итого: {format_money(total, catalog.currency)}</b>"])
        return "\n".join(lines)

    async def show_cart(callback: CallbackQuery) -> None:
        if not callback.from_user:
            return
        items = await prepared_cart(callback.from_user.id)
        await edit_callback(callback, cart_text(items), cart_keyboard(items))

    async def notify_admins(bot: Bot, order_id: int) -> None:
        order = await database.order(order_id)
        if order is None:
            return
        edit_details = await database.edit_order_details(order_id)
        buyer = (
            f'Покупатель: <a href="tg://user?id={order["user_id"]}">'
            f"{order['user_id']}</a>"
        )
        if edit_details:
            text = (
                f"🎬 <b>Новый заказ эдита №{order_id}</b>\n"
                f"{buyer}\n\n"
                f"Время: <b>{edit_details['seconds']} сек</b>\n"
                f"Песня: <b>{escape(str(edit_details['song']))}</b>\n"
                f"Персонаж / машина: <b>{escape(str(edit_details['subject']))}</b>\n"
                f"Тряска: <b>{'Да' if edit_details['shake'] else 'Нет'}</b>\n"
                f"Промокод: <b>{escape(str(edit_details['promo_code'])) if edit_details['promo_code'] else '—'}</b>\n\n"
                f"<b>Итоговая сумма: {format_money(int(order['total_minor']), 'G')}</b>"
                f"\n\nЗавершить: <code>/complete {order_id}</code>"
                f"\nОтменить: <code>/cancel_order {order_id}</code>"
            )
        else:
            items = await database.order_items(order_id)
            item_lines = [
                f"• {escape(str(item['title']))} × {item['quantity']} — "
                f"{format_money(int(item['price_minor']) * int(item['quantity']), str(order['currency']))}"
                for item in items
            ]
            text = (
                f"🆕 <b>Новый заказ №{order_id}</b>\n"
                f"{buyer}\n"
                f"Телефон: <code>{escape(str(order['phone']))}</code>\n\n"
                + "\n".join(item_lines)
                + f"\n\n<b>Итого: {format_money(int(order['total_minor']), str(order['currency']))}</b>"
                + (
                    f"\nКомментарий: {escape(str(order['comment']))}"
                    if order["comment"]
                    else ""
                )
                + f"\n\nЗавершить: <code>/complete {order_id}</code>"
                + f"\nОтменить: <code>/cancel_order {order_id}</code>"
            )
        for admin_id in settings.admin_ids:
            try:
                await bot.send_message(admin_id, text)
            except TelegramAPIError:
                # Ошибка одного администратора не должна отменять заказ.
                continue

    async def finish_checkout(
        message: Message, state: FSMContext, comment: str
    ) -> None:
        if not message.from_user:
            return
        data = await state.get_data()
        phone = str(data.get("phone", "")).strip()
        cart_items = await prepared_cart(message.from_user.id)
        if not cart_items:
            await state.clear()
            await message.answer(
                "Корзина пуста или товары были удалены из каталога.",
                reply_markup=main_menu(),
            )
            return

        products = []
        for item in cart_items:
            product = catalog.product(str(item["product_id"]))
            if product:
                products.append((product, int(item["quantity"])))

        order_id = await database.create_order(
            user_id=message.from_user.id,
            phone=phone,
            comment=comment,
            currency=catalog.currency,
            items=products,
        )
        await state.clear()
        await message.answer(
            f"✅ <b>Заказ №{order_id} создан.</b>\n\n"
            "Он появился в истории покупок. После подтверждения заказа "
            "администратором вы сможете оставить отзыв.",
            reply_markup=main_menu(),
        )
        await notify_admins(message.bot, order_id)

    @router.message(Command("start"))
    async def command_start(message: Message, state: FSMContext) -> None:
        await state.clear()
        await ensure_user(message)
        await message.answer(
            "Привет. Вы желаете выбрать товар.",
            reply_markup=main_menu(),
        )

    @router.message(Command("menu"))
    async def command_menu(message: Message, state: FSMContext) -> None:
        await state.clear()
        await ensure_user(message)
        await message.answer("Главное меню:", reply_markup=main_menu())

    @router.message(StateFilter("*"), F.text == BTN_CANCEL)
    @router.message(StateFilter("*"), Command("cancel"))
    async def cancel_action(message: Message, state: FSMContext) -> None:
        await state.clear()
        await message.answer("Действие отменено.", reply_markup=main_menu())

    @router.message(StateFilter(None), F.text == BTN_SHOP)
    async def shop_from_menu(message: Message) -> None:
        await ensure_user(message)
        reload_catalog()
        await message.answer(
            "🛍 <b>Магазин</b>\n\nВыберите раздел:",
            reply_markup=store_keyboard(catalog, settings.webapp_url),
        )

    @router.callback_query(F.data == "store")
    async def shop_from_callback(callback: CallbackQuery) -> None:
        reload_catalog()
        await edit_callback(
            callback,
            "🛍 <b>Магазин</b>\n\nВыберите раздел:",
            store_keyboard(catalog, settings.webapp_url),
        )
        await callback.answer()

    @router.callback_query(F.data.startswith("cat:"))
    async def open_category(callback: CallbackQuery) -> None:
        reload_catalog()
        category_id = (callback.data or "").split(":", 1)[1]
        category = catalog.category(category_id)
        if category is None:
            await callback.answer("Раздел больше не существует", show_alert=True)
            return
        text = f"<b>{escape(category.title)}</b>"
        if category.description:
            text += f"\n\n{escape(category.description)}"
        if not category.products:
            text += "\n\nАссортимент пока не добавлен."
        await edit_callback(callback, text, category_keyboard(category, catalog))
        await callback.answer()

    @router.callback_query(F.data.startswith("product:"))
    async def open_product(callback: CallbackQuery) -> None:
        reload_catalog()
        product_id = (callback.data or "").split(":", 1)[1]
        product = catalog.product(product_id)
        category = catalog.category_for_product(product_id)
        if product is None or category is None:
            await callback.answer("Товар больше не существует", show_alert=True)
            return
        text = (
            f"<b>{escape(product.title)}</b>\n\n"
            f"{escape(product.description) if product.description else 'Описание будет добавлено позже.'}\n\n"
            f"Цена: <b>{format_money(product.price_minor, catalog.currency)}</b>"
        )
        await edit_callback(callback, text, product_keyboard(product, category.id))
        await callback.answer()

    @router.callback_query(F.data.startswith("add:"))
    async def add_product(callback: CallbackQuery) -> None:
        reload_catalog()
        product_id = (callback.data or "").split(":", 1)[1]
        product = catalog.product(product_id)
        if product is None:
            await callback.answer("Товар больше не существует", show_alert=True)
            return
        await database.add_cart_item(callback.from_user.id, product.id)
        await callback.answer("Добавлено в корзину")

    @router.callback_query(F.data == "cart")
    async def open_cart(callback: CallbackQuery) -> None:
        await show_cart(callback)
        await callback.answer()

    @router.callback_query(F.data.startswith("cartinc:"))
    async def increase_cart(callback: CallbackQuery) -> None:
        product_id = (callback.data or "").split(":", 1)[1]
        await database.change_cart_quantity(callback.from_user.id, product_id, 1)
        await show_cart(callback)
        await callback.answer()

    @router.callback_query(F.data.startswith("cartdec:"))
    async def decrease_cart(callback: CallbackQuery) -> None:
        product_id = (callback.data or "").split(":", 1)[1]
        await database.change_cart_quantity(callback.from_user.id, product_id, -1)
        await show_cart(callback)
        await callback.answer()

    @router.callback_query(F.data.startswith("cartdel:"))
    async def delete_cart_item(callback: CallbackQuery) -> None:
        product_id = (callback.data or "").split(":", 1)[1]
        await database.remove_cart_item(callback.from_user.id, product_id)
        await show_cart(callback)
        await callback.answer("Товар удалён")

    @router.callback_query(F.data == "cartclear")
    async def clear_cart(callback: CallbackQuery) -> None:
        await database.clear_cart(callback.from_user.id)
        await show_cart(callback)
        await callback.answer("Корзина очищена")

    @router.callback_query(F.data == "noop")
    async def noop(callback: CallbackQuery) -> None:
        await callback.answer()

    @router.callback_query(F.data.startswith("buyedit:"))
    async def buy_edit(callback: CallbackQuery, bot: Bot) -> None:
        try:
            draft_id = int((callback.data or "").split(":", 1)[1])
        except ValueError:
            await callback.answer("Некорректный заказ", show_alert=True)
            return
        result = await database.submit_edit_draft(draft_id, callback.from_user.id)
        if result is None:
            await callback.answer(
                "Этот заказ уже отправлен или отменён.", show_alert=True
            )
            return
        order, _ = result
        order_id = int(order["id"])
        await edit_callback(
            callback,
            f"✅ <b>Заказ №{order_id} отправлен продавцу.</b>\n\n"
            f"Итоговая сумма: <b>{format_money(int(order['total_minor']), 'G')}</b>\n"
            "Статус можно посмотреть в истории покупок.",
        )
        await callback.answer("Заказ отправлен")
        await notify_admins(bot, order_id)

    @router.callback_query(F.data.startswith("canceledit:"))
    async def cancel_edit_draft(callback: CallbackQuery) -> None:
        try:
            draft_id = int((callback.data or "").split(":", 1)[1])
        except ValueError:
            await callback.answer("Некорректный заказ", show_alert=True)
            return
        canceled = await database.cancel_edit_draft(draft_id, callback.from_user.id)
        if not canceled:
            await callback.answer("Этот заказ уже обработан.", show_alert=True)
            return
        await edit_callback(callback, "Черновик заказа отменён.")
        await callback.answer()

    @router.callback_query(F.data == "checkout")
    async def begin_checkout(callback: CallbackQuery, state: FSMContext) -> None:
        items = await prepared_cart(callback.from_user.id)
        if not items:
            await callback.answer("Корзина пуста", show_alert=True)
            return
        await state.set_state(Checkout.waiting_phone)
        if callback.message:
            await callback.message.answer(
                "Для оформления заказа отправьте номер телефона кнопкой ниже "
                "или введите его сообщением.",
                reply_markup=phone_keyboard(),
            )
        await callback.answer()

    @router.message(Checkout.waiting_phone, F.contact)
    async def checkout_contact(message: Message, state: FSMContext) -> None:
        if not message.contact:
            return
        await state.update_data(phone=message.contact.phone_number)
        await state.set_state(Checkout.waiting_comment)
        await message.answer(
            "Добавьте комментарий к заказу или нажмите «Пропустить».",
            reply_markup=comment_keyboard(),
        )

    @router.message(Checkout.waiting_phone, F.text)
    async def checkout_phone_text(message: Message, state: FSMContext) -> None:
        phone = (message.text or "").strip()
        if len(phone) < 5 or len(phone) > 30:
            await message.answer("Введите корректный номер телефона.")
            return
        await state.update_data(phone=phone)
        await state.set_state(Checkout.waiting_comment)
        await message.answer(
            "Добавьте комментарий к заказу или нажмите «Пропустить».",
            reply_markup=comment_keyboard(),
        )

    @router.message(Checkout.waiting_comment, F.text == BTN_SKIP)
    async def checkout_skip_comment(message: Message, state: FSMContext) -> None:
        await finish_checkout(message, state, "")

    @router.message(Checkout.waiting_comment, F.text)
    async def checkout_comment(message: Message, state: FSMContext) -> None:
        comment = (message.text or "").strip()
        if len(comment) > 1000:
            await message.answer("Комментарий слишком длинный. Максимум 1000 символов.")
            return
        await finish_checkout(message, state, comment)

    @router.message(StateFilter(None), F.text == BTN_HISTORY)
    async def purchase_history(message: Message) -> None:
        await ensure_user(message)
        if not message.from_user:
            return
        orders = await database.user_orders(message.from_user.id)
        if not orders:
            await message.answer("История покупок пока пуста.")
            return

        lines = ["🧾 <b>История покупок</b>", ""]
        for order in orders:
            items = await database.order_items(int(order["id"]))
            item_names = ", ".join(
                f"{escape(str(item['title']))} × {item['quantity']}" for item in items
            )
            lines.extend(
                [
                    f"<b>Заказ №{order['id']}</b> — {STATUS_LABELS[str(order['status'])]}",
                    item_names,
                    f"Сумма: {format_money(int(order['total_minor']), str(order['currency']))}",
                    "",
                ]
            )
        await message.answer(
            "\n".join(lines),
            reply_markup=history_keyboard(orders),
        )

    @router.message(F.text == BTN_REVIEWS)
    async def public_reviews(message: Message) -> None:
        reviews = await database.reviews()
        if not reviews:
            await message.answer(
                "⭐ <b>Отзывы</b>\n\nОтзывов пока нет. Их смогут оставлять "
                "покупатели после завершения заказа."
            )
            return
        lines = ["⭐ <b>Отзывы покупателей</b>", ""]
        for review in reviews:
            lines.extend(
                [
                    "⭐" * int(review["rating"]),
                    escape(str(review["text"])),
                    f"<i>Заказ №{review['order_id']}</i>",
                    "",
                ]
            )
        await message.answer("\n".join(lines))

    @router.callback_query(F.data.startswith("review:"))
    async def begin_review(callback: CallbackQuery, state: FSMContext) -> None:
        try:
            order_id = int((callback.data or "").split(":", 1)[1])
        except ValueError:
            await callback.answer("Некорректный заказ", show_alert=True)
            return
        if not await database.can_review(callback.from_user.id, order_id):
            await callback.answer(
                "Отзыв доступен только после завершения покупки и один раз.",
                show_alert=True,
            )
            return
        await state.set_state(ReviewForm.waiting_rating)
        await state.update_data(review_order_id=order_id)
        if callback.message:
            await callback.message.answer(
                f"Оцените заказ №{order_id}:",
                reply_markup=rating_keyboard(order_id),
            )
        await callback.answer()

    @router.callback_query(ReviewForm.waiting_rating, F.data.startswith("rating:"))
    async def set_review_rating(callback: CallbackQuery, state: FSMContext) -> None:
        parts = (callback.data or "").split(":")
        if len(parts) != 3:
            await callback.answer("Некорректная оценка", show_alert=True)
            return
        try:
            order_id, rating = int(parts[1]), int(parts[2])
        except ValueError:
            await callback.answer("Некорректная оценка", show_alert=True)
            return
        data = await state.get_data()
        if order_id != data.get("review_order_id") or rating not in range(1, 6):
            await callback.answer("Некорректная оценка", show_alert=True)
            return
        await state.update_data(review_rating=rating)
        await state.set_state(ReviewForm.waiting_text)
        if callback.message:
            await callback.message.answer(
                "Напишите текст отзыва одним сообщением.\n"
                "Отзыв сразу появится в общем разделе."
            )
        await callback.answer()

    @router.message(ReviewForm.waiting_text, F.text)
    async def save_review(message: Message, state: FSMContext) -> None:
        text = (message.text or "").strip()
        if len(text) < 3 or len(text) > 1500:
            await message.answer("Отзыв должен содержать от 3 до 1500 символов.")
            return
        data = await state.get_data()
        try:
            await database.create_review(
                user_id=message.from_user.id,
                order_id=int(data["review_order_id"]),
                rating=int(data["review_rating"]),
                text=text,
            )
        except (KeyError, ValueError):
            await state.clear()
            await message.answer(
                "Не удалось сохранить отзыв. Возможно, он уже был оставлен.",
                reply_markup=main_menu(),
            )
            return
        await state.clear()
        await message.answer(
            "Спасибо! Ваш отзыв опубликован.",
            reply_markup=main_menu(),
        )

    @router.message(Checkout.waiting_phone)
    async def checkout_phone_fallback(message: Message) -> None:
        await message.answer("Отправьте номер телефона текстом или кнопкой ниже.")

    @router.message(Checkout.waiting_comment)
    async def checkout_comment_fallback(message: Message) -> None:
        await message.answer("Отправьте комментарий текстом или нажмите «Пропустить».")

    @router.message(ReviewForm.waiting_rating)
    async def review_rating_fallback(message: Message) -> None:
        await message.answer("Выберите оценку кнопкой под сообщением.")

    @router.message(ReviewForm.waiting_text)
    async def review_text_fallback(message: Message) -> None:
        await message.answer("Отправьте текст отзыва одним текстовым сообщением.")

    def is_admin(message: Message) -> bool:
        return bool(message.from_user and message.from_user.id in settings.admin_ids)

    def command_order_id(message: Message) -> int | None:
        parts = (message.text or "").split(maxsplit=1)
        if len(parts) != 2:
            return None
        try:
            return int(parts[1])
        except ValueError:
            return None

    @router.message(Command("orders"))
    async def admin_orders(message: Message) -> None:
        if not is_admin(message):
            await message.answer("Команда недоступна.")
            return
        orders = await database.pending_orders()
        if not orders:
            await message.answer("Новых заказов нет.")
            return
        lines = ["<b>Заказы, ожидающие подтверждения:</b>", ""]
        for order in orders:
            buyer = f"@{order['username']}" if order["username"] else order["user_id"]
            lines.append(
                f"№{order['id']} — {format_money(int(order['total_minor']), str(order['currency']))} "
                f"— {escape(str(buyer))}"
            )
        lines.append(
            "\nИспользуйте <code>/complete ID</code> или <code>/cancel_order ID</code>."
        )
        await message.answer("\n".join(lines))

    @router.message(Command("complete"))
    async def admin_complete(message: Message, bot: Bot) -> None:
        if not is_admin(message):
            await message.answer("Команда недоступна.")
            return
        order_id = command_order_id(message)
        if order_id is None:
            await message.answer("Формат: <code>/complete 123</code>")
            return
        order = await database.set_order_status(order_id, "completed")
        if order is None:
            await message.answer("Заказ не найден или уже обработан.")
            return
        await message.answer(f"Заказ №{order_id} завершён.")
        try:
            await bot.send_message(
                int(order["user_id"]),
                f"✅ Заказ №{order_id} завершён. Теперь в истории покупок "
                "можно оставить отзыв.",
            )
        except TelegramAPIError:
            pass

    @router.message(Command("cancel_order"))
    async def admin_cancel(message: Message, bot: Bot) -> None:
        if not is_admin(message):
            await message.answer("Команда недоступна.")
            return
        order_id = command_order_id(message)
        if order_id is None:
            await message.answer("Формат: <code>/cancel_order 123</code>")
            return
        order = await database.set_order_status(order_id, "canceled")
        if order is None:
            await message.answer("Заказ не найден или уже обработан.")
            return
        await message.answer(f"Заказ №{order_id} отменён.")
        try:
            await bot.send_message(int(order["user_id"]), f"Заказ №{order_id} отменён.")
        except TelegramAPIError:
            pass

    @router.message(Command("help"))
    async def help_command(message: Message) -> None:
        text = (
            "Используйте кнопки главного меню.\n\n"
            "Команды:\n"
            "/start — запустить бота\n"
            "/menu — открыть главное меню\n"
            "/cancel — отменить текущее действие"
        )
        if is_admin(message):
            text += (
                "\n\n<b>Администратор:</b>\n"
                "/orders — новые заказы\n"
                "/complete ID — завершить заказ\n"
                "/cancel_order ID — отменить заказ"
            )
        await message.answer(text)

    @router.message()
    async def unknown_message(message: Message) -> None:
        await message.answer(
            "Выберите действие с помощью кнопок меню.", reply_markup=main_menu()
        )

    return router
