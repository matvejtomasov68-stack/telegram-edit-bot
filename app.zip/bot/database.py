import asyncio
from collections.abc import Iterable
from pathlib import Path
from typing import Any

import aiosqlite

from .catalog import Product
from .pricing import Quote


class Database:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.connection: aiosqlite.Connection | None = None
        self._write_lock = asyncio.Lock()

    @property
    def db(self) -> aiosqlite.Connection:
        if self.connection is None:
            raise RuntimeError("Соединение с базой данных не открыто")
        return self.connection

    async def connect(self) -> None:
        self.connection = await aiosqlite.connect(self.path)
        self.connection.row_factory = aiosqlite.Row
        await self.connection.execute("PRAGMA foreign_keys = ON")
        await self.connection.execute("PRAGMA journal_mode = WAL")

    async def close(self) -> None:
        if self.connection is not None:
            await self.connection.close()
            self.connection = None

    async def init(self) -> None:
        await self.db.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS cart_items (
                user_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
                product_id TEXT NOT NULL,
                quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
                PRIMARY KEY (user_id, product_id)
            );

            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(user_id),
                status TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending', 'completed', 'canceled')),
                total_minor INTEGER NOT NULL CHECK (total_minor >= 0),
                currency TEXT NOT NULL,
                phone TEXT NOT NULL,
                comment TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                completed_at TEXT
            );

            CREATE TABLE IF NOT EXISTS order_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
                product_id TEXT NOT NULL,
                title TEXT NOT NULL,
                price_minor INTEGER NOT NULL CHECK (price_minor >= 0),
                quantity INTEGER NOT NULL CHECK (quantity > 0)
            );

            CREATE TABLE IF NOT EXISTS reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER NOT NULL UNIQUE REFERENCES orders(id) ON DELETE CASCADE,
                user_id INTEGER NOT NULL REFERENCES users(user_id),
                rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
                text TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS edit_drafts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(user_id),
                seconds INTEGER NOT NULL CHECK (seconds BETWEEN 5 AND 60),
                song TEXT NOT NULL,
                subject TEXT NOT NULL,
                shake INTEGER NOT NULL CHECK (shake IN (0, 1)),
                promo_code TEXT NOT NULL DEFAULT '',
                unit_price_minor INTEGER NOT NULL CHECK (unit_price_minor >= 0),
                shake_price_minor INTEGER NOT NULL CHECK (shake_price_minor >= 0),
                discount_minor INTEGER NOT NULL CHECK (discount_minor >= 0),
                total_minor INTEGER NOT NULL CHECK (total_minor >= 0),
                status TEXT NOT NULL DEFAULT 'draft'
                    CHECK (status IN ('draft', 'submitted', 'canceled')),
                order_id INTEGER UNIQUE REFERENCES orders(id),
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS edit_order_details (
                order_id INTEGER PRIMARY KEY REFERENCES orders(id) ON DELETE CASCADE,
                seconds INTEGER NOT NULL,
                song TEXT NOT NULL,
                subject TEXT NOT NULL,
                shake INTEGER NOT NULL CHECK (shake IN (0, 1)),
                promo_code TEXT NOT NULL DEFAULT '',
                unit_price_minor INTEGER NOT NULL,
                shake_price_minor INTEGER NOT NULL,
                discount_minor INTEGER NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id, created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status, created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_reviews_created ON reviews(created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_edit_drafts_user ON edit_drafts(user_id, id DESC);
            """
        )
        await self.db.commit()

    async def upsert_user(
        self, user_id: int, username: str | None, first_name: str | None
    ) -> None:
        await self.db.execute(
            """
            INSERT INTO users (user_id, username, first_name)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                username = excluded.username,
                first_name = excluded.first_name,
                updated_at = CURRENT_TIMESTAMP
            """,
            (user_id, username, first_name or ""),
        )
        await self.db.commit()

    async def add_cart_item(self, user_id: int, product_id: str) -> None:
        await self.db.execute(
            """
            INSERT INTO cart_items (user_id, product_id, quantity)
            VALUES (?, ?, 1)
            ON CONFLICT(user_id, product_id) DO UPDATE SET
                quantity = quantity + 1
            """,
            (user_id, product_id),
        )
        await self.db.commit()

    async def change_cart_quantity(
        self, user_id: int, product_id: str, delta: int
    ) -> None:
        await self.db.execute(
            """
            UPDATE cart_items
            SET quantity = quantity + ?
            WHERE user_id = ? AND product_id = ?
            """,
            (delta, user_id, product_id),
        )
        await self.db.execute(
            """
            DELETE FROM cart_items
            WHERE user_id = ? AND product_id = ? AND quantity <= 0
            """,
            (user_id, product_id),
        )
        await self.db.commit()

    async def remove_cart_item(self, user_id: int, product_id: str) -> None:
        await self.db.execute(
            "DELETE FROM cart_items WHERE user_id = ? AND product_id = ?",
            (user_id, product_id),
        )
        await self.db.commit()

    async def clear_cart(self, user_id: int) -> None:
        await self.db.execute("DELETE FROM cart_items WHERE user_id = ?", (user_id,))
        await self.db.commit()

    async def cart(self, user_id: int) -> list[dict[str, Any]]:
        cursor = await self.db.execute(
            "SELECT product_id, quantity FROM cart_items WHERE user_id = ?",
            (user_id,),
        )
        return [dict(row) for row in await cursor.fetchall()]

    async def create_order(
        self,
        user_id: int,
        phone: str,
        comment: str,
        currency: str,
        items: Iterable[tuple[Product, int]],
    ) -> int:
        item_list = list(items)
        if not item_list:
            raise ValueError("Нельзя создать пустой заказ")

        total_minor = sum(
            product.price_minor * quantity for product, quantity in item_list
        )
        await self.db.execute("BEGIN IMMEDIATE")
        try:
            cursor = await self.db.execute(
                """
                INSERT INTO orders (user_id, total_minor, currency, phone, comment)
                VALUES (?, ?, ?, ?, ?)
                """,
                (user_id, total_minor, currency, phone, comment),
            )
            order_id = int(cursor.lastrowid or 0)
            await self.db.executemany(
                """
                INSERT INTO order_items
                    (order_id, product_id, title, price_minor, quantity)
                VALUES (?, ?, ?, ?, ?)
                """,
                [
                    (order_id, product.id, product.title, product.price_minor, quantity)
                    for product, quantity in item_list
                ],
            )
            await self.db.execute(
                "DELETE FROM cart_items WHERE user_id = ?", (user_id,)
            )
            await self.db.commit()
            return order_id
        except Exception:
            await self.db.rollback()
            raise

    async def order(self, order_id: int) -> dict[str, Any] | None:
        cursor = await self.db.execute("SELECT * FROM orders WHERE id = ?", (order_id,))
        row = await cursor.fetchone()
        return dict(row) if row else None

    async def order_items(self, order_id: int) -> list[dict[str, Any]]:
        cursor = await self.db.execute(
            """
            SELECT product_id, title, price_minor, quantity
            FROM order_items WHERE order_id = ? ORDER BY id
            """,
            (order_id,),
        )
        return [dict(row) for row in await cursor.fetchall()]

    async def user_orders(self, user_id: int, limit: int = 10) -> list[dict[str, Any]]:
        cursor = await self.db.execute(
            """
            SELECT o.*,
                   EXISTS(SELECT 1 FROM reviews r WHERE r.order_id = o.id) AS has_review
            FROM orders o
            WHERE o.user_id = ?
            ORDER BY o.id DESC
            LIMIT ?
            """,
            (user_id, limit),
        )
        return [dict(row) for row in await cursor.fetchall()]

    async def pending_orders(self, limit: int = 20) -> list[dict[str, Any]]:
        cursor = await self.db.execute(
            """
            SELECT o.*, u.username, u.first_name
            FROM orders o
            JOIN users u ON u.user_id = o.user_id
            WHERE o.status = 'pending'
            ORDER BY o.id
            LIMIT ?
            """,
            (limit,),
        )
        return [dict(row) for row in await cursor.fetchall()]

    async def set_order_status(
        self, order_id: int, status: str
    ) -> dict[str, Any] | None:
        if status not in {"completed", "canceled"}:
            raise ValueError("Недопустимый статус")
        completed = "CURRENT_TIMESTAMP" if status == "completed" else "NULL"
        cursor = await self.db.execute(
            f"""
            UPDATE orders
            SET status = ?, completed_at = {completed}
            WHERE id = ? AND status = 'pending'
            """,
            (status, order_id),
        )
        if cursor.rowcount == 0:
            await self.db.rollback()
            return None
        await self.db.commit()
        return await self.order(order_id)

    async def can_review(self, user_id: int, order_id: int) -> bool:
        cursor = await self.db.execute(
            """
            SELECT 1
            FROM orders o
            LEFT JOIN reviews r ON r.order_id = o.id
            WHERE o.id = ? AND o.user_id = ? AND o.status = 'completed'
              AND r.id IS NULL
            """,
            (order_id, user_id),
        )
        return await cursor.fetchone() is not None

    async def create_review(
        self, user_id: int, order_id: int, rating: int, text: str
    ) -> None:
        if not await self.can_review(user_id, order_id):
            raise ValueError("Для этого заказа нельзя оставить отзыв")
        await self.db.execute(
            """
            INSERT INTO reviews (order_id, user_id, rating, text)
            VALUES (?, ?, ?, ?)
            """,
            (order_id, user_id, rating, text),
        )
        await self.db.commit()

    async def reviews(self, limit: int = 20) -> list[dict[str, Any]]:
        cursor = await self.db.execute(
            """
            SELECT r.id, r.order_id, r.rating, r.text, r.created_at
            FROM reviews r
            ORDER BY r.id DESC
            LIMIT ?
            """,
            (limit,),
        )
        return [dict(row) for row in await cursor.fetchall()]

    async def create_edit_draft(
        self,
        user_id: int,
        song: str,
        subject: str,
        shake: bool,
        quote: Quote,
    ) -> int:
        async with self._write_lock:
            cursor = await self.db.execute(
                """
                INSERT INTO edit_drafts (
                    user_id, seconds, song, subject, shake, promo_code,
                    unit_price_minor, shake_price_minor, discount_minor, total_minor
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    user_id,
                    quote.seconds,
                    song,
                    subject,
                    int(shake),
                    quote.promo_code,
                    quote.unit_price * 100,
                    quote.shake_price * 100,
                    quote.discount * 100,
                    quote.total * 100,
                ),
            )
            await self.db.commit()
            return int(cursor.lastrowid or 0)

    async def edit_draft(self, draft_id: int) -> dict[str, Any] | None:
        cursor = await self.db.execute(
            "SELECT * FROM edit_drafts WHERE id = ?", (draft_id,)
        )
        row = await cursor.fetchone()
        return dict(row) if row else None

    async def submit_edit_draft(
        self, draft_id: int, user_id: int
    ) -> tuple[dict[str, Any], dict[str, Any]] | None:
        async with self._write_lock:
            await self.db.execute("BEGIN IMMEDIATE")
            try:
                cursor = await self.db.execute(
                    """
                    SELECT * FROM edit_drafts
                    WHERE id = ? AND user_id = ? AND status = 'draft'
                    """,
                    (draft_id, user_id),
                )
                row = await cursor.fetchone()
                if row is None:
                    await self.db.rollback()
                    return None
                draft = dict(row)

                order_cursor = await self.db.execute(
                    """
                    INSERT INTO orders
                        (user_id, status, total_minor, currency, phone, comment)
                    VALUES (?, 'pending', ?, 'G', 'Telegram', '')
                    """,
                    (user_id, draft["total_minor"]),
                )
                order_id = int(order_cursor.lastrowid or 0)
                await self.db.execute(
                    """
                    INSERT INTO order_items
                        (order_id, product_id, title, price_minor, quantity)
                    VALUES (?, 'custom_edit', ?, ?, 1)
                    """,
                    (
                        order_id,
                        f"Эдит — {draft['seconds']} сек",
                        draft["total_minor"],
                    ),
                )
                await self.db.execute(
                    """
                    INSERT INTO edit_order_details (
                        order_id, seconds, song, subject, shake, promo_code,
                        unit_price_minor, shake_price_minor, discount_minor
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        order_id,
                        draft["seconds"],
                        draft["song"],
                        draft["subject"],
                        draft["shake"],
                        draft["promo_code"],
                        draft["unit_price_minor"],
                        draft["shake_price_minor"],
                        draft["discount_minor"],
                    ),
                )
                await self.db.execute(
                    """
                    UPDATE edit_drafts
                    SET status = 'submitted', order_id = ?
                    WHERE id = ?
                    """,
                    (order_id, draft_id),
                )
                await self.db.commit()
            except Exception:
                await self.db.rollback()
                raise

        order = await self.order(order_id)
        if order is None:
            return None
        draft["order_id"] = order_id
        draft["status"] = "submitted"
        return order, draft

    async def cancel_edit_draft(self, draft_id: int, user_id: int) -> bool:
        async with self._write_lock:
            cursor = await self.db.execute(
                """
                UPDATE edit_drafts SET status = 'canceled'
                WHERE id = ? AND user_id = ? AND status = 'draft'
                """,
                (draft_id, user_id),
            )
            await self.db.commit()
            return cursor.rowcount > 0

    async def edit_order_details(self, order_id: int) -> dict[str, Any] | None:
        cursor = await self.db.execute(
            "SELECT * FROM edit_order_details WHERE order_id = ?", (order_id,)
        )
        row = await cursor.fetchone()
        return dict(row) if row else None
