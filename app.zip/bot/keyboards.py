from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    WebAppInfo,
)

from .catalog import Catalog, Category, Product, format_money

BTN_REVIEWS = "⭐ Отзывы"
BTN_SHOP = "🛍 Магазин"
BTN_HISTORY = "🧾 История покупок"
BTN_CANCEL = "❌ Отмена"
BTN_SKIP = "Пропустить"


def main_menu() -> ReplyKeyboardMarkup:
    # В Telegram строка может содержать одну кнопку, поэтому правый нижний угол пуст.
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=BTN_REVIEWS), KeyboardButton(text=BTN_SHOP)],
            [KeyboardButton(text=BTN_HISTORY)],
        ],
        resize_keyboard=True,
        input_field_placeholder="Выберите раздел",
    )


def store_keyboard(
    catalog: Catalog, webapp_url: str | None = None
) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for category in catalog.categories:
        if category.id == "edit" and webapp_url:
            button = InlineKeyboardButton(
                text=category.title,
                web_app=WebAppInfo(url=webapp_url),
            )
        else:
            button = InlineKeyboardButton(
                text=category.title,
                callback_data=f"cat:{category.id}",
            )
        rows.append([button])
    rows.append([InlineKeyboardButton(text="🛒 Корзина", callback_data="cart")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def category_keyboard(category: Category, catalog: Catalog) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text=f"{product.title} — {format_money(product.price_minor, catalog.currency)}",
                callback_data=f"product:{product.id}",
            )
        ]
        for product in category.products
    ]
    rows.extend(
        [
            [InlineKeyboardButton(text="🛒 Корзина", callback_data="cart")],
            [InlineKeyboardButton(text="⬅️ К разделам", callback_data="store")],
        ]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def product_keyboard(product: Product, category_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="➕ Добавить в корзину", callback_data=f"add:{product.id}"
                )
            ],
            [InlineKeyboardButton(text="🛒 Корзина", callback_data="cart")],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data=f"cat:{category_id}")],
        ]
    )


def cart_keyboard(items: list[dict[str, object]]) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for item in items:
        product_id = str(item["product_id"])
        title = str(item["title"])
        rows.append(
            [
                InlineKeyboardButton(text="➖", callback_data=f"cartdec:{product_id}"),
                InlineKeyboardButton(text=title[:24], callback_data="noop"),
                InlineKeyboardButton(text="➕", callback_data=f"cartinc:{product_id}"),
                InlineKeyboardButton(text="✖️", callback_data=f"cartdel:{product_id}"),
            ]
        )
    if items:
        rows.append(
            [InlineKeyboardButton(text="✅ Оформить", callback_data="checkout")]
        )
        rows.append(
            [InlineKeyboardButton(text="🗑 Очистить", callback_data="cartclear")]
        )
    rows.append([InlineKeyboardButton(text="⬅️ В магазин", callback_data="store")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def phone_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📱 Отправить мой номер", request_contact=True)],
            [KeyboardButton(text=BTN_CANCEL)],
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


def comment_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=BTN_SKIP)],
            [KeyboardButton(text=BTN_CANCEL)],
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


def history_keyboard(orders: list[dict[str, object]]) -> InlineKeyboardMarkup | None:
    buttons = [
        [
            InlineKeyboardButton(
                text=f"⭐ Оставить отзыв к заказу №{order['id']}",
                callback_data=f"review:{order['id']}",
            )
        ]
        for order in orders
        if order["status"] == "completed" and not order["has_review"]
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons) if buttons else None


def rating_keyboard(order_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"{rating} ⭐", callback_data=f"rating:{order_id}:{rating}"
                )
                for rating in range(1, 6)
            ]
        ]
    )


def edit_draft_keyboard(draft_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Купить", callback_data=f"buyedit:{draft_id}")],
            [
                InlineKeyboardButton(
                    text="Отменить", callback_data=f"canceledit:{draft_id}"
                )
            ],
        ]
    )
