"""Telegram shop bot package."""
