import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parent.parent


@dataclass(frozen=True, slots=True)
class Settings:
    bot_token: str
    admin_ids: frozenset[int]
    database_path: Path
    catalog_path: Path
    promocodes_path: Path
    webapp_url: str | None
    web_host: str
    web_port: int
    edit_price_per_second: int
    edit_shake_surcharge: int


def _project_path(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else PROJECT_ROOT / path


def _positive_int(name: str, default: str, *, allow_zero: bool = False) -> int:
    try:
        value = int(os.getenv(name, default))
    except ValueError as exc:
        raise RuntimeError(f"{name} должен быть целым числом") from exc
    minimum = 0 if allow_zero else 1
    if value < minimum:
        raise RuntimeError(f"{name} должен быть не меньше {minimum}")
    return value


def load_settings() -> Settings:
    load_dotenv(PROJECT_ROOT / ".env")

    token = os.getenv("BOT_TOKEN", "").strip()
    if not token or token.endswith("replace_me"):
        raise RuntimeError(
            "BOT_TOKEN не задан. Скопируйте .env.example в .env и укажите токен BotFather."
        )

    raw_admins = os.getenv("ADMIN_IDS", "")
    try:
        admin_ids = frozenset(
            int(item.strip()) for item in raw_admins.split(",") if item.strip()
        )
    except ValueError as exc:
        raise RuntimeError(
            "ADMIN_IDS должен содержать Telegram ID через запятую."
        ) from exc

    database_path = _project_path(os.getenv("DATABASE_PATH", "data/shop.sqlite3"))
    catalog_path = _project_path(os.getenv("CATALOG_PATH", "data/catalog.json"))
    promocodes_path = _project_path(
        os.getenv("PROMOCODES_PATH", "data/promocodes.json")
    )
    database_path.parent.mkdir(parents=True, exist_ok=True)

    webapp_base = os.getenv("WEBAPP_URL", "").strip().rstrip("/") or None
    if webapp_base and not webapp_base.startswith("https://"):
        raise RuntimeError("WEBAPP_URL должен начинаться с https://")
    webapp_url = None
    if webapp_base:
        webapp_url = (
            f"{webapp_base}/" if webapp_base.endswith("/app") else f"{webapp_base}/app/"
        )

    return Settings(
        bot_token=token,
        admin_ids=admin_ids,
        database_path=database_path,
        catalog_path=catalog_path,
        promocodes_path=promocodes_path,
        webapp_url=webapp_url,
        web_host=os.getenv("WEB_HOST", "0.0.0.0").strip() or "0.0.0.0",
        web_port=_positive_int("WEB_PORT", os.getenv("PORT", "8080")),
        edit_price_per_second=_positive_int("EDIT_PRICE_PER_SECOND", "2"),
        edit_shake_surcharge=_positive_int(
            "EDIT_SHAKE_SURCHARGE", "20", allow_zero=True
        ),
    )
