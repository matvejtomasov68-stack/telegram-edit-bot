from __future__ import annotations

import hmac
import json
from hashlib import sha256
from html import escape
from pathlib import Path
from time import time
from urllib.parse import parse_qsl

from aiogram import Bot
from aiogram.exceptions import TelegramAPIError
from aiohttp import web

from .config import PROJECT_ROOT, Settings
from .database import Database
from .keyboards import edit_draft_keyboard
from .pricing import Pricing, PromoCodeError, Quote

WEBAPP_INDEX = PROJECT_ROOT / "webapp" / "index.html"


def validate_init_data(
    init_data: str, bot_token: str, max_age_seconds: int = 3600
) -> dict[str, str] | None:
    if not init_data:
        return None
    fields = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = fields.pop("hash", "")
    if not received_hash:
        return None

    data_check_string = "\n".join(f"{key}={fields[key]}" for key in sorted(fields))
    secret_key = hmac.new(b"WebAppData", bot_token.encode(), sha256).digest()
    expected_hash = hmac.new(secret_key, data_check_string.encode(), sha256).hexdigest()
    if not hmac.compare_digest(expected_hash, received_hash):
        return None

    try:
        auth_date = int(fields["auth_date"])
    except (KeyError, ValueError):
        return None
    if abs(int(time()) - auth_date) > max_age_seconds:
        return None
    return fields


def draft_summary_text(
    draft_id: int,
    song: str,
    subject: str,
    shake: bool,
    quote: Quote,
) -> str:
    lines = [
        "🎬 <b>Проверьте заказ</b>",
        "",
        f"Время: <b>{quote.seconds} сек</b>",
        f"Песня: <b>{escape(song)}</b>",
        f"Персонаж / машина: <b>{escape(subject)}</b>",
        f"Тряска: <b>{'Да' if shake else 'Нет'}</b>",
        f"Промокод: <b>{escape(quote.promo_code) if quote.promo_code else '—'}</b>",
        "",
        f"Расчёт: {quote.seconds} × {quote.unit_price}G = {quote.base_price}G",
    ]
    if quote.shake_price:
        lines.append(f"Тряска: +{quote.shake_price}G")
    if quote.discount:
        lines.append(f"Промокод: −{quote.discount}G")
    lines.extend(
        [
            f"<b>Итоговая сумма: {quote.total}G</b>",
            "",
            "Нажмите «Купить», чтобы отправить заказ продавцу.",
            f"<i>Черновик №{draft_id}</i>",
        ]
    )
    return "\n".join(lines)


def create_web_application(
    bot: Bot,
    database: Database,
    settings: Settings,
    pricing: Pricing,
    index_path: Path = WEBAPP_INDEX,
) -> web.Application:
    @web.middleware
    async def security_headers(
        request: web.Request, handler: web.RequestHandler
    ) -> web.StreamResponse:
        response = await handler(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self' 'unsafe-inline' https://telegram.org; "
            "style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:"
        )
        return response

    app = web.Application(
        middlewares=[security_headers],
        client_max_size=16 * 1024,
    )

    async def index(_: web.Request) -> web.FileResponse:
        return web.FileResponse(index_path)

    async def health(_: web.Request) -> web.Response:
        return web.json_response({"status": "ok"})

    async def config(_: web.Request) -> web.Response:
        return web.json_response(
            {
                "unit_price": pricing.unit_price,
                "shake_surcharge": pricing.shake_surcharge,
            }
        )

    async def create_draft(request: web.Request) -> web.Response:
        try:
            payload = await request.json()
        except (json.JSONDecodeError, web.HTTPBadRequest):
            return web.json_response({"message": "Некорректные данные"}, status=400)
        if not isinstance(payload, dict):
            return web.json_response({"message": "Некорректные данные"}, status=400)

        init_fields = validate_init_data(
            str(payload.get("init_data", "")), settings.bot_token
        )
        if init_fields is None:
            return web.json_response(
                {"message": "Откройте форму через кнопку в Telegram-боте"},
                status=401,
            )
        try:
            user = json.loads(init_fields["user"])
            user_id = int(user["id"])
        except (KeyError, TypeError, ValueError, json.JSONDecodeError):
            return web.json_response(
                {"message": "Не удалось определить покупателя"}, status=401
            )

        errors: dict[str, str] = {}
        seconds = payload.get("seconds")
        if (
            isinstance(seconds, bool)
            or not isinstance(seconds, int)
            or not 5 <= seconds <= 60
        ):
            errors["seconds"] = "Эдит заказать можно от 5с - 60с"

        song = str(payload.get("song", "")).strip()
        subject = str(payload.get("subject", "")).strip()
        promo_code = str(payload.get("promo_code", "")).strip()
        shake = payload.get("shake")
        if not song or len(song) > 200:
            errors["song"] = "Укажите песню (до 200 символов)"
        if not subject or len(subject) > 200:
            errors["subject"] = "Укажите персонажа или машину (до 200 символов)"
        if not isinstance(shake, bool):
            errors["shake"] = "Выберите «Да» или «Нет»"
        if len(promo_code) > 32:
            errors["promo"] = "Промокод слишком длинный"
        if errors:
            return web.json_response(
                {"message": "Проверьте поля", "errors": errors}, status=422
            )

        try:
            quote = pricing.quote(seconds, shake, promo_code)
        except PromoCodeError as exc:
            return web.json_response(
                {"message": str(exc), "errors": {"promo": str(exc)}}, status=422
            )
        except ValueError as exc:
            return web.json_response(
                {"message": str(exc), "errors": {"seconds": str(exc)}}, status=422
            )

        await database.upsert_user(
            user_id,
            str(user.get("username", "")) or None,
            str(user.get("first_name", "")),
        )
        draft_id = await database.create_edit_draft(
            user_id=user_id,
            song=song,
            subject=subject,
            shake=shake,
            quote=quote,
        )
        try:
            await bot.send_message(
                user_id,
                draft_summary_text(draft_id, song, subject, shake, quote),
                reply_markup=edit_draft_keyboard(draft_id),
            )
        except TelegramAPIError:
            await database.cancel_edit_draft(draft_id, user_id)
            return web.json_response(
                {
                    "message": "Бот не смог отправить итог. Вернитесь в чат и попробуйте снова."
                },
                status=500,
            )
        return web.json_response({"ok": True, "draft_id": draft_id})

    app.router.add_get("/", health)
    app.router.add_get("/health", health)
    app.router.add_get("/app", index)
    app.router.add_get("/app/", index)
    app.router.add_get("/api/config", config)
    app.router.add_post("/api/edit-draft", create_draft)
    return app
