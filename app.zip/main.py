import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiohttp import web

from bot.catalog import Catalog
from bot.config import load_settings
from bot.database import Database
from bot.handlers import create_router
from bot.pricing import Pricing
from bot.webapp import create_web_application


async def main() -> None:
    settings = load_settings()
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )
    logger = logging.getLogger("main")

    catalog = Catalog(settings.catalog_path)
    catalog.reload()
    pricing = Pricing(
        settings.promocodes_path,
        unit_price=settings.edit_price_per_second,
        shake_surcharge=settings.edit_shake_surcharge,
    )

    database = Database(settings.database_path)
    await database.connect()
    await database.init()

    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dispatcher = Dispatcher()
    dispatcher.include_router(create_router(database, catalog, settings))

    web_application = create_web_application(bot, database, settings, pricing)
    runner = web.AppRunner(web_application)
    await runner.setup()
    site = web.TCPSite(runner, settings.web_host, settings.web_port)
    await site.start()
    logger.info(
        "Mini App server started on %s:%s", settings.web_host, settings.web_port
    )
    if not settings.webapp_url:
        logger.warning(
            "WEBAPP_URL is empty: set a public HTTPS URL to enable the Edit form in Telegram"
        )

    try:
        await bot.delete_webhook(drop_pending_updates=False)
        await dispatcher.start_polling(bot)
    finally:
        await runner.cleanup()
        await database.close()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
